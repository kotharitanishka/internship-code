import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) throws InterruptedException {

        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss:SSS");

        Thread.sleep(15000);

        long begin = System.currentTimeMillis();
        String timestampBegin = formatter.format(begin);
        System.out.println("begin time in simple format : " + timestampBegin + " and in epoch time : " + begin);

        System.out.println("multithread");
        List<Thread> threads = new ArrayList<>();
        Runnable task = () -> { System.out.println("Hello Platform Thread"); };
        for (Integer i = 0; i <= 10000 ; i++) {
            //Multithread multithread = new Multithread(i.toString());
            Thread myThread = new Thread(task);
            threads.add(myThread);
        }


        // System.out.println("Virtual threads");
        // List<Thread> threads = new ArrayList<>();
        // Runnable task = () -> { System.out.println("Hello Virtual Thread"); };
        // for (Integer i = 0; i <= 10000; i++) {
        //     Thread mythread = Thread.ofVirtual().unstarted(task);
        //     threads.add(mythread);
        // }

        
        threads.forEach(thread -> thread.start());
        for (Thread thread : threads) {
            thread.join();
        }

        long end = System.currentTimeMillis();
        String timestampEnd = formatter.format(begin);
        System.out.println("end time in simple format: " + timestampEnd + " and in epoch time : " + end);

        Thread.sleep(5000);

        long total = end - begin;
        System.out.println("\n\ntotal time taken in seconds --> " + total/1000.0);

    }
}

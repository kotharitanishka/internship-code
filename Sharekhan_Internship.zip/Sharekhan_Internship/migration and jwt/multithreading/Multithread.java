public class Multithread implements Runnable {

    public String threadName;

    public Multithread(String threadName) {
        this.threadName = threadName;
    }

    @Override
    public void run() {

        // try {
        // System.out.println("\nmultithread class before -->\n");
        // Thread.sleep(7000);
        // } catch (InterruptedException e) {
        // System.out.println("went to catch");
        // }

        for (Integer i = 0; i <= 2; i++) {
           System.out.println(i + " this is from thread number : " + threadName);
            // try {
            //     //System.out.println("multithread class for loop from thread , i --> " + threadName + " " + i);
            //     Thread.sleep(3000);
            // } catch (InterruptedException e) {
            //     System.out.println("went to catch");
            // }

        }

        // try {
        // System.out.println("\nmultithread class after  -->\n");
        // Thread.sleep(7000);
        // } catch (InterruptedException e) {
        // System.out.println("went to catch");
        // }

        //System.out.println(java.time.LocalTime.now());

    }

}

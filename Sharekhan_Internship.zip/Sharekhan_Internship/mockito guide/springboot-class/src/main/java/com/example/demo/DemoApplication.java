package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
// THIS LITTLE ANNOTATION HERE MANAGES THE ENTIRE CONTEXT OF THE APP AUTOMATICALLY 
//DO NOT NEED TO EXPLICITLY INSTANTIATE IT

public class DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

}

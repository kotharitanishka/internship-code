package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mockConstruction;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedConstruction;
import org.mockito.MockitoAnnotations;
//import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.example.demo.config.ConnectionBean;
import com.example.demo.controller.Controller;
import com.redis.lettucemod.api.StatefulRedisModulesConnection;
import com.redis.lettucemod.api.sync.RedisModulesCommands;

@ExtendWith(MockitoExtension.class)
public class demoTest {

    @Mock
    ConnectionBean connectionBean;

    @Mock
    StatefulRedisModulesConnection<String, String> connection;

    @Mock
    RedisModulesCommands<String, String> commands ;

    @InjectMocks
    Controller controller ;

    // @BeforeEach
	// public void init() {
	// 	MockitoAnnotations.openMocks(this);
	// }

    @Test
    public void Controllertest(){
        System.out.println("\n\ntesting\n\n");

       // System.out.println(connection.getClass());
        System.out.println(commands.getClass());

        when(connection.sync()).thenReturn(commands);  
        
        when(commands.set("key" , "value")).thenReturn("abc");  
        String result = controller.getBook2();
        verify(commands).set("key" , "value");
        //verify(connection).sync();
        System.out.println(result == null);
        assertEquals(result , "abc");
    }
    
}

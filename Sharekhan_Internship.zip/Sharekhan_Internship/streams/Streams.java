import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Streams {
      public static void main(String[] args) {

            List<String> names = Arrays.asList("Ankit", "Kushal", "Brent", "Sarika", "amanda", "Hans", "Shivika",
                        "Sarah");

            List<String> updatedNames = names.stream()
                        .map(String::toUpperCase)
                        .filter(x -> x.startsWith("S"))
                        .sorted()
                        .collect(Collectors.toList());

            System.out.println(updatedNames + "\n");

            Map<String, Integer> hashmap = new HashMap<>();
            Stream<String> nameStream = names.stream();
            hashmap = nameStream.filter(x -> x.length() > 5)
                        .map(String::toLowerCase)
                        .collect(Collectors.toMap(x -> x, x -> x.length()));

            System.out.println("\n" + hashmap);

            Stream<Map.Entry<String, Integer>> streamMap = hashmap.entrySet().stream();

            List<Map.Entry<String, Integer>> listFromMap = streamMap.collect(Collectors.toList());
            System.out.println("\n" + listFromMap);


            Map<String, String> stringMap = new HashMap<>();
            stringMap.put("name", "abc");
            stringMap.put("dob", "18-10-1990");
            stringMap.put("pet", "dog");

      

            List<List<String>> combined = new ArrayList<>();
            List<String> name1 = new ArrayList<>();
            List<String> name2 = new ArrayList<>();
            name1.add("abc");
            name1.add("def");
            name2.add("xyz");
            name2.add("uvw");
            combined.add(name1);
            combined.add(name2);
            System.out.println(combined);

            List<String> tryFlatmap = combined.stream().flatMap(x -> x.stream()).collect(Collectors.toList());
            System.out.println(tryFlatmap);

            int[] numbers = { 1, 8, 3, 6, 5, 4, 7, 2 };

            int answer = Arrays.stream(numbers).sum();
            System.out.println(answer + "\n");

            IntStream numbersStream = Arrays.stream(numbers);

            numbersStream
                        .map(x -> x * x)
                        .sorted()
                        .forEach(System.out::println);

      }

}
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.concurrent.Flow;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.net.http.HttpRequest;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse;
import java.net.URI;
import java.net.http.HttpClient;
import org.json.*;
//import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class Main {

    public static void main(String[] args) throws InterruptedException, IOException {

        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss:SSS");

        // Thread.sleep(15000);

        long begin = System.currentTimeMillis();
        String timestampBegin = formatter.format(begin);
        System.out.println("begin time in simple format : " + timestampBegin + " and in epoch time : " + begin);

        File file = new File("C:\\Tanishka\\Sharekhan_Internship\\WriteTest.txt");
        FileWriter fileWriter = new FileWriter(file);
        BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
        // System.out.println(Files.lines(file.toPath()).count());

        List<Thread> threadApi = new ArrayList<>();
        for (Integer i = 0; i <= 5; i++) {
            String stringURL = ("https://jsonplaceholder.typicode.com/photos?_page=" + i.toString() + "&_limit=5");
            Runnable task = () -> {
                HttpRequest request = HttpRequest.newBuilder()
                        .uri(URI.create(stringURL))
                        .method("GET", BodyPublishers.noBody())
                        .build();
                HttpResponse<String> response;
                try {
                    response = HttpClient.newHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
                    String stringResponse = response.body();
                    JSONArray jsonArrayResponse = new JSONArray(stringResponse);
                    

                    JSONObject jsonObject1 = jsonArrayResponse.getJSONObject(0);
                    JSONObject jsonObject2 = jsonArrayResponse.getJSONObject(1);
                    JSONObject jsonObject3 = jsonArrayResponse.getJSONObject(2);
                    JSONObject jsonObject4 = jsonArrayResponse.getJSONObject(3);
                    JSONObject jsonObject5 = jsonArrayResponse.getJSONObject(4);

                    // bufferedWriter.write(jsonArrayResponse.toString() +
                    // System.getProperty("line.separator"));

                    bufferedWriter.write(jsonObject1.toString() +
                    System.getProperty("line.separator")
                    + jsonObject2.toString() + System.getProperty("line.separator") +
                    jsonObject3.toString()
                    + System.getProperty("line.separator") + jsonObject4.toString()
                    + System.getProperty("line.separator") + jsonObject5.toString());

                    // bufferedWriter.write(jsonObject1.toString()
                    //         + jsonObject2.toString() + jsonObject3.toString()
                    //         + jsonObject4.toString()
                    //         + jsonObject5.toString() + System.getProperty("line.separator"));
                } catch (IOException e) {
                    System.out.println("error1" + e);
                } catch (InterruptedException e) {
                    System.out.println("error2");
                }

            };

            // Thread myThread = new Thread(task);
            Thread myThread = Thread.ofVirtual().unstarted(task);
            threadApi.add(myThread);
        }

        threadApi.forEach(thread -> {
            thread.start();
        });
        for (Thread thread : threadApi) {
            thread.join();
        }
        bufferedWriter.close();
        // fileWriter.close();

        long end = System.currentTimeMillis();
        String timestampEnd = formatter.format(begin);
        System.out.println("\nend time in simple format: " + timestampEnd + " and in epoch time : " + end);

        // Thread.sleep(5000);

        long total = end - begin;
        System.out.println("\n\ntotal time taken in seconds --> " + total / 1000.0);
        System.out.println(Files.lines(file.toPath()).count());
        System.out.println("Java 21 Virtual threads");
        // System.out.println("Java 17 multithreading");

    }
}

public class Multithread implements Runnable {

    public String threadName;

    public Multithread(String threadName) {
        this.threadName = threadName;
    }

    @Override
    public void run() {

        // try {
        // System.out.println("\nmultithread class before -->\n");
        // Thread.sleep(7000);
        // } catch (InterruptedException e) {
        // System.out.println("went to catch");
        // }

        for (Integer i = 0; i <= 2; i++) {
           System.out.println(i + " this is from thread number : " + threadName);
            // try {
            //     //System.out.println("multithread class for loop from thread , i --> " + threadName + " " + i);
            //     Thread.sleep(3000);
            // } catch (InterruptedException e) {
            //     System.out.println("went to catch");
            // }

        }

        // try {
        // System.out.println("\nmultithread class after  -->\n");
        // Thread.sleep(7000);
        // } catch (InterruptedException e) {
        // System.out.println("went to catch");
        // }

        //System.out.println(java.time.LocalTime.now());

    }

}

// HttpRequest request = HttpRequest.newBuilder()
        // .uri(URI.create("https://jsonplaceholder.typicode.com/comments?_page=250&_limit=2"))
        // .method("GET", BodyPublishers.noBody())
        // .build();

        // HttpResponse<String> response = null;

        // try {
        // response = HttpClient.newHttpClient().send(request,
        // HttpResponse.BodyHandlers.ofString());
        // //System.out.println(response.body());
        // } catch (IOException e) {
        // e.printStackTrace();
        // } catch (InterruptedException e) {
        // e.printStackTrace();
        // }
        // System.out.println("\n");
        // String stringResponse = response.body();
        // JSONArray jsonArrayResponse = new JSONArray(stringResponse);
        // System.out.println(jsonArrayResponse);
        // Integer n = jsonArrayResponse.length();

        // String filename = "C:\\Tanishka\\Sharekhan_Internship\\Test.txt";
        // Path path = Paths.get(filename);
        // Scanner scanner = new Scanner(path);
        // long lineCount = Files.lines(path).count();

        // List<Thread> threads = new ArrayList<>();

        // File file = new File("C:\\Tanishka\\Sharekhan_Internship\\WriteTest.txt");
        // FileWriter fileWriter = new FileWriter(file);
        // BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
        // System.out.println(Files.lines(file.toPath()).count());

        for (Integer i = 0 ; i < n ; i ++){
        //JSONObject jsonObject = new JSONObject();
        JSONObject jsonObject = jsonArrayResponse.getJSONObject(i);
        Runnable task = () -> {
        try {
        //fileWriter.write(jsonObject.toString() +
        System.getProperty("line.separator"));
        bufferedWriter.write(jsonObject.toString() +
        System.getProperty("line.separator"));
        } catch (IOException e) {
        System.out.println("error");
        }
        // };
        // Thread myThread = new Thread(task);
        // //Thread myThread = Thread.ofVirtual().unstarted(task);
        // threads.add(myThread);
        // }

        // while (scanner.hasNextLine()) {
        // String line = scanner.nextLine();
        // Runnable task = () -> {
        // try {
        // //fileWriter.write(line + System.getProperty("line.separator"));
        // bufferedWriter.write(line.replace(",", "").replace(".", "") +
        // System.getProperty("line.separator"));
        // } catch (IOException e) {
        // System.out.println("io exception");
        // }
        // };
        // //Thread myThread = new Thread(task);
        // Thread myThread = Thread.ofVirtual().unstarted(task);
        // threads.add(myThread);
        // }
        // scanner.close();
package com.example.demo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@Configuration
public class ConnectionBean{

    @Bean(name = "test-db")
    public String getDb(){
        return "db connection";
    }
    

}
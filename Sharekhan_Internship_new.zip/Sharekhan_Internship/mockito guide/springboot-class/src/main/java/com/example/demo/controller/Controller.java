package com.example.demo.controller;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.config.ConnectionBean;
import com.redis.lettucemod.api.StatefulRedisModulesConnection;
import com.redis.lettucemod.api.sync.RedisModulesCommands;

@RestController
public class Controller {

    @Autowired
    private ConnectionBean customBean;

    @Autowired
    StatefulRedisModulesConnection<String, String> connection;

    RedisModulesCommands<String, String> commands;

    // public Controller(StatefulRedisModulesConnection<String, String> conn) {
    // connection = conn;
    // commands = connection.sync();
    // }

    // @Autowired
    // ApplicationContext applicationContext;

    @GetMapping("/v5")
    public String getBook2() {
        commands = connection.sync();
        String ans = commands.set("key", "value");
        System.out.println("-------------> just checking!");
        //System.out.println(Arrays.asList(applicationContext.getBean("test-db")));
        return ans;

    }

}
